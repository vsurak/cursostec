#ifndef _PALETA_
#define _PALETA_ 0

#include <iostream>

struct paleta{

    int cantproducto;

};

#endif