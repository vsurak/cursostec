#ifndef _PEDIDOS_
#define _PEDIDOS_ 0

#include <iostream>
#include "bodega.h"

using namespace std;

struct pedidos {
    int cantidad[10];
    //bodega pedidos[];
};

#endif